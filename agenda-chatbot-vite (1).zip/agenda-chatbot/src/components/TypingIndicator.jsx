import React from 'react';

export default function TypingIndicator() {
  return (
    <div className="row row--bot">
      <div className="typing">
        <span /><span /><span />
      </div>
    </div>
  );
}
